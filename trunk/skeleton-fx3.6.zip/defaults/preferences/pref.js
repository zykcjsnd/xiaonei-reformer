pref("extensions.xiaonei_reformer.xnr_options", "{}");
